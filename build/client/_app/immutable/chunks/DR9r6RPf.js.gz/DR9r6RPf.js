import{m as a}from"./Cq4Xyxph.js";a();
