import{l as o,a as r}from"../chunks/BWS25_X7.js";export{o as load_css,r as start};
